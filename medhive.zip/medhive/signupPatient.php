<?php
  include('connect.php');
  if (isset($_POST['submit'])) {
     
      $first_name=$_POST['first_name'];
      $last_name=$_POST['last_name'];
      $gender=$_POST['gender'];
      $email=$_POST['email'];
      $username=$_POST['username'];
      $password=$_POST['password'];
      $acc_type='1';
      $status = '0';
      $image = $_FILES['image']['name'];
      $target = "ids/".basename($image);


    $sql= "Select * From `account` Where first_name= '$first_name' and last_name= '$last_name'";
    $selectresult=mysqli_query($con, $sql);
    $number=mysqli_num_rows($selectresult);

    if ($number>0)
    {
      echo"<script>alert('Name already exist')</script>";
    }
    else
    {
      $sql = "insert into `account` (first_name, last_name, gender, email, username, password, status, acc_type, pic_img) values ( '$first_name', '$last_name', '$gender','$email','$username','$password', '$status', '$acc_type', '$image')";
      $result = mysqli_query($con, $sql);
      if($result)
      {
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        echo "<script>alert('Upload Successful')</script>";
        echo "<script> window.open('login.php', '_self')</script>";
      }
    }
      else
      {
        die (mysqli_error($con));
      }
    }
  }

?>

 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <link rel ="stylesheet" href = "./css/buttons.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Patient Signup</title>
  </head>
  <body>
 

    <div class="container my-5">
        <div class="header">
          <h3>Patient Registration</h3>
        </div>
      <form method="post" enctype="multipart/form-data">
        <div class="form-group">
          <input type="text" required="required" class="form-control" placeholder="Enter First Name" name="first_name">
        </div>
        <br>
        <div class="form-group">
          <input type="text" required="required" class="form-control" placeholder="Enter Last Name" name="last_name">
        </div>
        <br>
        <div class="form-group">
          <input type="text" required="required" class="form-control" placeholder="Enter your Email" name="email">
        </div>
        <br>
               <div class="gender">
    <select id="gender" name="gender">
            <option value="genderr">-Select Gender-</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
    </select>
</div><br>
        <div class="form-group">
          <input type="text" required="required" class="form-control" placeholder="Enter Username" name="username">
        </div><br>
          <div class="form-group">
          <input type="password" required="required" class="form-control" placeholder="Enter Password" name="password">
        </div>
        <br>
          <div class="form-group">
          <input type="file" required="required" class="form-control" name="image">
        </div>
        <br>
         </div>
   
      
    
</select>

      <button type="submit" class="btn btn-dark" name="submit" >Submit</button>

      <center>
         <br>
     <a href="login.php" class="btn btn-dark" style="text-decoration: none; color: white;">Cancel</a>
     </center>
      </form>

    </div>

  </body>
</html>
