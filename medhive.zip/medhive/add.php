<?php
  include('connect.php');



if(isset($_GET['acct_id']))
  {
    $id = $_GET['acct_id'];
    $select_query="Select * from `account` WHERE acct_id = $id";
    $result=mysqli_query($con,$select_query);

     while ($row=mysqli_fetch_assoc($result)) 
       {

      $id=$row['acct_id'];
      $firstname=$row['first_name'];
     }

  }


  if (isset($_POST['submit'])) {

    $patient    =$_POST['patient'];
    $date       =$_POST['date'];
    $time       =$_POST['time'];
    $type       =$_POST['type'];




  $sql = "INSERT INTO `appointments` (conf_doc_id, conf_pat_id, sched_date, sched_time, type) VALUES ( '$id', '$patient', '$date', '$time', '$type')";

    $result = mysqli_query($con, $sql);

    if($result){
      echo "<script>alert ('Data inserted successfully')  </script>";
    }else{
      die(mysqli_error($con));
    }

  }

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="designation.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">


    <title>ASEAN Phonebook</title>
  </head>
  <body>
    
    <div class="container my-5">

      <form method="POST">
    <div class="mb-3">
      <input type="number" required="required" class="form-control" name="patient" placeholder="What's your account ID">
    </div>
    <div class="mb-3">
      <input id="surtext" type="date" cglass="" placeholder="Enter the Surname" name="date" required="required">
      <input id="firtext" type="time" class="" id="exampleInputPassword1" placeholder="Please the First Name" required="required" name="time">
                         <select class="dropdown-trigger btn" name="type">
                        <option value="1">Face to face</option>
                        <option value="0">Virtual</option>
                    </select>
    </div>
    </div>

    <br>
    <br>




    <button type="submit" class="btn waves-effect waves-light" name="submit"> Appoint </button>
      </form>







    </div>


  <footer class="page-footer teal lighten-2" style="
body {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  main {
    flex: 1 0 auto;
  }">

  <center>
    &copy; Copyright 2022 Panzo Paulo, All Rights Reserved

   
  </center>
</footer>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>