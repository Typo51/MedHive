<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<link rel="stylesheet" type="text/css" href="css/sidebar.css">
</head>
<body>
<div class="wrapper">

	<!-- SIDE BAR -->
    <div class="sidebar">
        <ul>
            <li><a href="#"><i class="fa-solid fa-table-columns"></i>  Dashboard </a></li>
            <li><a href="#"><i class="fa-solid fa-user"></i> Profile </a></li>
            <li><a href="#"><i class="fa-solid fa-sliders"></i> Preferences </a></li>
        </ul> 
    </div>
</body>
</html>