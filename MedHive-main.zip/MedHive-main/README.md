Records Center Features:

	-Lab Results, Med Certs and Other Recs. ✓
	-Allows the patients to share specific documents to doctors ✓
	-Delete Button Feature.
	-Back button.
	-Share button Modal. ✓

Security Features:

	-Asks password when opening Docs Center. ✓
	-Asks password when sharing a specific document. ✓
	-Anti X-site, sql-injection and phishing sites. ✓

Polish:

	-redesign Database (optional)
	-redesign UI
	-Terms and conditions Declaration
	-Vital Stats of Patients ✓
	-Email Confirmation and Notifications
	-Move Doctor Availability to Doctors Profile
	-User Info Redesign (Signup and Patients Profile)

Testing:

	-Find 3 doctors.
	-Find Patients
	-Test the UI using the testing guide.
	-Record user's feedbacks and comments.
  
Papers:
