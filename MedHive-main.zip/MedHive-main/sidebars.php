<?php 

    include ('connect.php');
    session_start();

    $user_id = $_SESSION['user_id'];
    $type = $_SESSION['acc_type'];


    if(isset($_GET['acct_id']))
    {
        $id = $_GET['acct_id'];
        $select_query="Select * from `account` WHERE acct_id = $user_id";
        $result=mysqli_query($con,$select_query);

       while ($row=mysqli_fetch_assoc($result)) 
           {

            $id=$row['acct_id'];
            $firstname=$row['first_name'];

         }

    }
 ?>

<!doctype html>
<html lang="en">
  <head>
  
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="./css/patientsdb.css">
	<link rel="stylesheet" href="./css/buttons.css">
	<link rel="stylesheet" href="./css/modals.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/sidebars.css">
  </head>
  <body>


  
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
				<div class="p-4 pt-5">
		  		<h1><a href="index.html" class="logo">Splash</a></h1>
	        <ul class="list-unstyled components mb-5">
	          <li class="active">
	            <a <?php 

                            

if ($_SESSION['acc_type'] == 0){
    echo "href='patientsDB.php?acct_id=$user_id'";
}
else{

    echo "href='doctorDB.php?acct_id=$user_id'";
}

?>>Home</a>
	      
	          </li>
	          <li>
	              <a href="#">About</a>
	          </li>
	          <li>
              <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Pages</a>
              <ul class="collapse list-unstyled" id="pageSubmenu">
                <li>
                    <a href="#">Page 1</a>
                </li>
                <li>
                    <a href="#">Page 2</a>
                </li>
                <li>
                    <a href="#">Page 3</a>
                </li>
              </ul>
	          </li>
	          <li>
              <a href="#">Portfolio</a>
	          </li>
	          <li>
              <a href="#">Contact</a>
	          </li>
	        </ul>

	        <div class="mb-5">
						<h3 class="h6">Subscribe for newsletter</h3>
						<form action="#" class="colorlib-subscribe-form">
	            <div class="form-group d-flex">
	            	<div class="icon"><span class="icon-paper-plane"></span></div>
	              <input type="text" class="form-control" placeholder="Enter Email Address">
	            </div>
	          </form>
					</div>

	        <div class="footer">
	        	<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib.com</a>
						  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
	        </div>

	      </div>
    	</nav>

        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5 pt-5">
        <div class='welcome-bubble'>
				<h3>Welcome, <?php echo $_SESSION['user'];?> </h3>
    		</div>

    <!-- ABOVE BUTTONS TO OPEN MODALS -->

    <div class="main_content">
        <div class="header">
        	<div>
        		<a href="#" onclick="appointment()"> <button class="btn btn-primary">Set an appointment</button></a> 
        	</div>
	
        	<div>
				<a href="#" onclick="conference()"> <button class="btn btn-primary">Join a conference</button></a> 
        	</div>
        	
        	<div>
				<a href="#" onclick="logs()"> <button class="btn btn-primary">Appointment Logs</button></a> 
        	</div>
        	</a>
        </div>

        <!-- DOCTORS LIST -->
        
        <div class="patient-list-container-outside">
			<table class="list">
				<thead>
					<tr>
						<th style="width: 70px;"> </th>
						<th>Doctor's Name</th>
	   					
						<th>Specialization</th>
						<th>Status</th>
					</tr>
				</thead>
	
				<tbody>
					<?php 

$select_query="Select * from `account` WHERE acc_type = '1'";
$result=mysqli_query($con,$select_query);

$i=1;
if($result)
{
while ($row=mysqli_fetch_assoc($result)) 
{
$id=$row['acct_id'];
 $surname=$row['last_name'];
 $firstname=$row['first_name']
; $status=$row['status'];
 $specialty=$row['specialization'];
						 
					     
					     echo " 
					     
							<tr class='clickable'>
							<td><img src='./images/icon.png'  width='40px' height='40px'></a></td>
							<td>$firstname $surname</a></td>
							<td>$specialty</td>
							<td>Online</td>
							
							</tr>";

					    $i++;
					   }
					}

					else{
					    die(mysqli_error($con));
					   }

					?>					
				</tbody>
	
	
			</table>
	</div>

        </div> 
    
    </div>
</div>

			<!-- MODALS -->

			<!-- SELECT DOCTOR MODAL -->
<div class="popup" id="modal1" >
	<div class="container">
		<h5>Please select a Doctor</h5>
		<form method="POST">
			<div class="patient-list-container-inside">
				<table class="list">
					<thead>
						<tr>
							<th style="width: 70px;"> </th>
							<th>Name</th>
							<th>Specialization</th>
						
						</tr>
					</thead>
		
					<tbody>
							
							<?php 

								
							     
								 $select_query="Select * from `account` WHERE acc_type = '1'";
						
						$result=mysqli_query($con,$select_query);
					$i=1;
					if($result)
					{
					   while ($row=mysqli_fetch_assoc($result)) 
					   {
					    $id=$row['acct_id'];
					     $surname=$row['last_name'];
					     $firstname=$row['first_name'];
					     $specialty=$row['specialization'];
						?>

							   
							     	
									<tr class='clickable'>
										<td><a data-toggle='#'><img src='./images/icon.png'  width='40px' height='40px'></a></td>
									<td><a href='doctorProfile.php?acct_id=<?php echo $row['acct_id']?>' onclick='doctorsModal1()''><?php echo " $firstname $surname"?></a></td>
										<td><a href='doctorProfile.php?acct_id=<?php echo $row['acct_id']?>' onclick='doctorsModal1()'><?php echo "$specialty" ?></a></td>
										
									</tr>
							<?php
							    $i++;
							   }
							}

							else{
							    die(mysqli_error($con));
							   }

							?>
						
					</tbody>
				</table>
			</form>
		


	</div>
	<div class="blurbg">
		<a href="#" onclick="appointment()"> <button class="buttons" id="cancel">Cancel</button></a> 
		
	</div>
	</div>
</div>


	<!-- CONFERENCE MODAL -->
 <div class="popup2" id="modal2">
		<div class="conference-container">
			<div class = "conference-box">
				<label class="labeling">Please input the Conference ID or Link</label>
				<input type="link" name="url">
				<a href="" target="blank" onclick="conference()"> 
					<button class="buttons" id="conference">Enter</button>
				</a>
			
			</div>
			

		</div>


	</div> 


	<!-- APPOINTMENT LOG MODAL -->
	<div class="popup3" id="modal3" >
	<div class="container">
	<div class="patient-list-container-outside">
			<table class="list">
				<thead>
					<tr>
						<th style="width: 70px;"> </th>
						<th>Doctor's Name</th>
	   					
						<th>Appointment Date</th>
						<th> Cancel Appointment</th>
						
					</tr>
				</thead>
	
				<tbody>

		<?php 
$patID = $_SESSION['user_id'];
$select_query="Select * from `appointment` WHERE pat_id = '$patID'";
$result=mysqli_query($con,$select_query);

$i=1;
if($result)
{
while ($row=mysqli_fetch_assoc($result)) 
{

 $scheddate=$row['sched_date'];
 $schedtime=$row['sched_time'];
 $doctorfullname=$row['docfullname'];
 
						 
					     
 ?>
 <tr>
	 <td><img src="./images/icon.png" alt="" style="width:40px; height:40px"></td>
	 <td><?php echo $doctorfullname ?></td>
	 <td><?php echo $scheddate." ".$schedtime ?></td>
	 <td><button type="button" style="color:red; border:none; cursor:pointer; background-color: inherit;" onclick="cancel_appointment(<?php echo $row['transaction_id']; ?>)" >CANCEL</button></td>
	
 </tr>
<?php

					    $i++;
					   }
					}

					else{
					    die(mysqli_error($con));
					   }

					?>		
					</tbody>		
		</table>
		
	</div><br>
	<a href="#" onclick="logs()"> <button class="buttons" id="cancel">Cancel</button></a> 
					</div>


          <script src="js/events.js">
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>