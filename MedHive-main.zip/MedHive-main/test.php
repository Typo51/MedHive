<?php 
 include('connect.php');
 include('side.php');
 ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Patient's Dashboard</title>
	<link rel="stylesheet" href="./css/patientsdb.css">
	<link rel="stylesheet" href="./css/buttons.css">
	<link rel="stylesheet" href="./css/modals.css">

	<!-- BOOTSTRAP -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <script src="https://kit.fontawesome.com/42135a69b7.js" crossorigin="anonymous"></script>


</head>
<body>


	<!-- WELCOME BUBBLE -->

	<?php 

	$select_query="Select first_name from `patient` WHERE patient_id LIKE 2";
	$result=mysqli_query($con,$select_query);

	   while ($row=mysqli_fetch_assoc($result)) 
	   {
	     $firstname=$row['first_name'];

	     /*PROFILE BUBBLE*/

	     echo " 
	   
	    	<div class='welcome-bubble'>
				<h5>Welcome, $firstname </h5>
    		</div>";

	   }
?>



    <!-- ABOVE BUTTONS TO OPEN MODALS -->

    <div class="main_content">
        <div class="header">
        	<div>
        		<a href="#" onclick="appointment()"> <button class="waves-effect waves-light btn">Set an appointment</button></a> 
        	</div>
	
        	<div>
				<a href="#" onclick="conference()"> <button class="waves-effect waves-light btn">Join a conference</button></a> 
        	</div>
        	
        	<div>
				<a href="#" onclick="logs()"> <button class="waves-effect waves-light btn">Appointment Logs</button></a> 
        	</div>
        	</a>
        </div>



	<script src="js/events.js"></script>
</body>
</html>



