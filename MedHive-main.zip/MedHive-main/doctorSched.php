
<?php
  include('connect.php');
  



session_start();

if(isset($_SESSION['user']) && $_SESSION['user'] != ''){

}
else{

}

if(isset($_GET['acct_id']))
  {
    $id = $_GET['acct_id'];
    $select_query="Select * from `account` WHERE acct_id = $id";
    $result=mysqli_query($con,$select_query);

     while ($row=mysqli_fetch_assoc($result)) 
       {

      $id=$row['acct_id'];
      $firstname=$row['first_name'];
      $doctorfullname=$row['first_name']." ".$row['last_name'];
     }

  }


  if (isset($_POST['submit'])) {
    $patientID  =$_SESSION['acc_id'];
    $sqlpatient="Select * from `account` WHERE acct_id = $patientID";
    $resultpatient=mysqli_query($con,$sqlpatient);
    $rowpatient = mysqli_fetch_assoc($resultpatient);
    $fullname= $rowpatient['first_name']." ".$rowpatient['last_name'];
   // $patient    =$_POST['patient'];
    $date       =$_POST['date'];
    $time       =$_POST['time'];
    $type       =$_POST['type'];
   



  $sql = "INSERT INTO `doctorsched` (doc_id, Fullname, docfullname, pat_id, sched_date, sched_time, `type`) VALUES ( '$id', '$fullname','$doctorfullname','$patientID', '$date', '$time', '$type')";


    $result = mysqli_query($con, $sql);

    if($result){
      echo "<script>alert ('Appointed!')  </script>";
      echo "<script>window.open('patientsdb.php','_self')</script>";


    }else{
      die(mysqli_error($con));
    }

  }

?>


<html> 

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
     <!-- Montserrat Font -->
     <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

<!-- Material Icons -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">

    <script src="https://kit.fontawesome.com/42135a69b7.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/doctorsched.css">


    <title>Doctor Schedule</title>
</head>

<body>

<div class="grid-container">


      <!-- Sidebar -->
      <aside id="sidebar">
        <div class="sidebar-title">
          <div class="sidebar-brand">
            <span class="material-icons-outlined">inventory</span> MedHive
          </div>
          <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
        </div>

        <ul class="sidebar-list">
          <li class="sidebar-list-item">
            <span class="material-icons-outlined">dashboard</span> Dashboard
          </li>
          <li class="sidebar-list-item">
            <span class="material-icons-outlined">person</span> Profile
          </li>
          <li class="sidebar-list-item">
            <span class="material-icons-outlined">fact_check</span> Preferences
          </li>
        </ul>    

        <div class="sidebar">
            <ul class ="sidebar-list"> 
          <li class="sidebar-list-item">
            <span class="material-icons-outlined">logout</span> Logout
          </li>
</ul>
      </aside>
      <!-- End Sidebar -->
<main class="main-container">
        <div class="main-title">
        <div class="charts">
        <div class="charts-card">

        <table class="list">
					<thead>
						<tr>
							<th style="width: 70px;"> </th>
							<th>Schedule of Unavailability</th>
							
						
						</tr>
					</thead>
</table>
		
<!-- schedule -->
      <input id="surtext" type="date" name="date" >Date
     
	     <div><input id="firtext" type="time" name="time">Time start</div>
        <div><input id="firtext" type="time" name="time">Time end</div>
        <input type="submit" name="submit" class="btnapp">

</div>
</div>
</div>


</main>

</div>


</body>

</html>