<?php 
	include('connect.php');

 ?>



 <!DOCTYPE html>
 <html>
 <head>
 	<title>
 		TEST
 	</title>
 </head>

 <style type="text/css">
 	
 	body{
 		background-color: #243447;
 	}

 	label{
 		color: white;
 	}


 </style>
 <body>


 
 <fieldset>
 	<legend>Appointment</legend>
 		<center>
 		<form method="POST">
 			

 			<?php 
 				if(isset($_POST['submit']))
 				{
 					$date = $_POST['date'];
 					$sql = "SELECT * FROM `doctors_availability` WHERE avail_date = '$date' AND status = 1";
 					 $result=mysqli_query($con,$sql);
 				

 				echo "<select name='sched_time'>";

 				while ($row=mysqli_fetch_assoc($result)) {
 					
 						 
 					?>

 						<option value='<?php echo $row['avail_time']; ?>'><?php echo $row['avail_time']; ?></option>


 					<?php 

 				}
 				echo "</select>";

 				
			}

			
			if(isset($_POST['appoint']))
 				{
 					$sched_time = $_POST['sched_time'];
 					$date = $_POST['date'];

 					$sql1 = "UPDATE `doctors_availability` SET `status`= '0' WHERE avail_date = '$date' AND  `avail_time` = '$sched_time'";
 					$resultar=mysqli_query($con,$sql1);
 				}

				

 			 ?>
 			 <input type="submit" name="appoint" value="Appoint!">
			<br>
 			<br>
 			 <input type="date" name="date" value='<?php echo $date ?>'>


 			



 			<input type="submit" name="submit" value="Pick Date">
 			

 			 
 		</form>



	
</select>


</center>
 </fieldset>
 </body>
 </html>