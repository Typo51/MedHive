# MedHive
A web application for our thesis


  MILESTONES: 
    1.) add booking calendar feature
    2.) admin dashboard feature
    3.) add notifications via text or email feature
    4.) emphasize the security and confidentiality
    5.) add state the privacy notice or consent notice
