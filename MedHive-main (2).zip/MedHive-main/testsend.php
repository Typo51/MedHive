<form class="" action="send.php" method="post">
<label>Email To:</label><input type="email" name="email" value=""><br>
     <label>Subject:</label><input type="text" name="subject" value=""><br>
     <label>Message:</label><input type="text" name="message" value=""><br><br>
 <button type="submit" name="send">Send</button>
         <a style="margin-left: 20px;" class="waves-effect waves-light btn" target="_blank" type="button" href="diagnosisPrescriptionForm.php?acct_id=<?php echo $id;?>&&date_id=<?php echo $date_id;?>">Appoint Patient</a>
         </form>