<?php
  include('connect.php');
  if (isset($_POST['submit'])) {
     
      $first_name=$_POST['first_name'];
      $last_name=$_POST['last_name'];
      $gender=$_POST['gender'];
      $email=$_POST['email'];
      $username=$_POST['username'];
      $password=$_POST['password'];
      $acc_type=$_POST['acc_type'];
     



    $sql= "Select * From `account` Where first_name= '$first_name' and last_name= '$last_name'";
    $selectresult=mysqli_query($con, $sql);
    $number=mysqli_num_rows($selectresult);

    if ($number>0)
    {
      echo"<script>alert('Name already exist')</script>";
    }
    else
    {
      $sql = "insert into `account` (first_name, last_name, gender, email, username, password, status, acc_type) values ( '$first_name', '$last_name', '$gender','$email','$username','$password', '$status', '$acc_type')";
      $result = mysqli_query($con, $sql);
      if($result)
      {
        echo "Data Inserted Successfully";
        echo "<script> window.open('login.php', '_self')</script>";
      }
      else
      {
        die (mysqli_error($con));
      }
    }
  }

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Store Data</title>
  </head>
  <body>
 

    <div class="container my-5">

      <form method="post">
        <div class="form-group">
          <label> First Name </label>
          <input type="text" required="required" class="form-control" placeholder="Enter First Name" name="first_name">
        </div>
        <br>
        <div class="form-group">
          <label> Last Name </label>
          <input type="text" required="required" class="form-control" placeholder="Enter First Name" name="last_name">
        </div>
        <br>
        <div class="form-group">
          <label>Email</label>
          <input type="text" required="required" class="form-control" placeholder="Enter your Email" name="email">
        </div>
        <br>
               <div class="gender">
  <label for="gender">Gender</label>
    <select id="gender" name="gender">
            <option value="genderr">-Select Gender-</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
    </select>
</div><br>
        <div class="form-group">
          <label> Username </label>
          <input type="text" required="required" class="form-control" placeholder="Enter Username" name="username">
        </div><br>
          <div class="form-group">
          <label> Password </label>
          <input type="password" required="required" class="form-control" placeholder="Enter Password" name="password">
        </div>
        <br>
        <label for="acc_type">User Type</label>
    <select id="acc_type" name="acc_type">
            <option value="User">-Select User Type-</option>
            <option value="1">Doctor</option>
            <option value="0">Patient</option>
         
   
       
    
      <br><br>
      <button type="submit" class="btn btn-dark" name="submit" >Submit</button>
      </form>

    </div>

  </body>
</html>
