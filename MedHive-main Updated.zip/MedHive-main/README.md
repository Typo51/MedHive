# MedHive
A web application for our thesis

TASKS LEFT:

    -PATIENT VIEW CSS

    -LOGIN LOGOUT FEATURE

    -SIDEBAR, HEADER AND FOOTER
