<?php 

$server = "localhost";
$user = "root";
$pass = "";
$database = "clinic2";

$con = mysqli_connect($server, $user, $pass, $database);

if (!$con) {
    die("<script>alert('Connection Failed.')</script>");
}

?>